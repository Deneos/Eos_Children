//Objet qui contient tout les blocs
var Level = function(id)
{
    this.id = id;
    this.ennemiTab = [];
    this.levelBlocs = [];
    this.tabBlocs = [];
    this.tabDynamicBlocs = [];
}